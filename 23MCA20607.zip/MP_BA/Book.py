import mysql.connector
from tkinter import *
from tkinter import messagebox

# Database Connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",       # Replace with your MySQL username
    password="11July2001@",    # Replace with your MySQL password
    database="ticket_booking"    # Ensure this matches your database name
)
cursor = conn.cursor()

# GUI Functions
def display_buses():
    cursor.execute("SELECT * FROM buses")
    buses = cursor.fetchall()
    bus_listbox.delete(0, END)
    for bus in buses:
        bus_listbox.insert(END, f"Bus ID: {bus[0]} | {bus[1]} (From {bus[2]} to {bus[3]}, Seats: {bus[4]})")

def book_ticket_gui():
    selected_bus = bus_listbox.get(ACTIVE)
    if not selected_bus:
        messagebox.showerror("Error", "Please select a bus to book.")
        return

    bus_id = int(selected_bus.split()[2])
    name = entry_name.get().strip()
    age = entry_age.get().strip()
    gender = entry_gender.get().strip()
    contact = entry_contact.get().strip()

    if not name or not age.isdigit() or not gender or not contact:
        messagebox.showerror("Input Error", "Please fill all passenger details correctly.")
        return

    age = int(age)
    cursor.execute("INSERT INTO passengers (passenger_name, age, gender, contact_number) VALUES (%s, %s, %s, %s)", 
                   (name, age, gender, contact))
    conn.commit()
    passenger_id = cursor.lastrowid

    cursor.execute("SELECT total_seats FROM buses WHERE bus_id = %s", (bus_id,))
    total_seats = cursor.fetchone()[0]
    
    cursor.execute("SELECT seat_number FROM bookings WHERE bus_id = %s", (bus_id,))
    booked_seats = [row[0] for row in cursor.fetchall()]
    available_seats = [seat for seat in range(1, total_seats + 1) if seat not in booked_seats]

    if available_seats:
        seat_number = available_seats[0]
        cursor.execute("INSERT INTO bookings (bus_id, passenger_id, seat_number) VALUES (%s, %s, %s)", 
                       (bus_id, passenger_id, seat_number))
        conn.commit()
        messagebox.showinfo("Success", f"Ticket booked! Seat Number: {seat_number}")
    else:
        messagebox.showerror("No Seats", "No seats available on this bus.")

# GUI Layout
root = Tk()
root.title("Bus Ticket Booking System")

Label(root, text="Available Buses:").grid(row=0, column=0, pady=10)
bus_listbox = Listbox(root, width=50)
bus_listbox.grid(row=1, column=0, padx=10, pady=10)
Button(root, text="Refresh Buses", command=display_buses).grid(row=2, column=0, padx=10, pady=5)

Label(root, text="Passenger Name:").grid(row=3, column=0, sticky=W, padx=10)
entry_name = Entry(root)
entry_name.grid(row=3, column=0, padx=120, pady=5)

Label(root, text="Age:").grid(row=4, column=0, sticky=W, padx=10)
entry_age = Entry(root)
entry_age.grid(row=4, column=0, padx=120, pady=5)

Label(root, text="Gender:").grid(row=5, column=0, sticky=W, padx=10)
entry_gender = Entry(root)
entry_gender.grid(row=5, column=0, padx=120, pady=5)

Label(root, text="Contact Number:").grid(row=6, column=0, sticky=W, padx=10)
entry_contact = Entry(root)
entry_contact.grid(row=6, column=0, padx=120, pady=5)

Button(root, text="Book Ticket", command=book_ticket_gui).grid(row=7, column=0, pady=10)

display_buses()
root.mainloop()

# Close connection on exit
conn.close()
